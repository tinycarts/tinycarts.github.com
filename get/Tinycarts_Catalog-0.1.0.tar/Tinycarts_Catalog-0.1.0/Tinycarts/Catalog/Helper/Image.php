<?php
/* vim: set expandtab tabstop=4 shiftwidth=4 softtabstop=4: */

/**
 * Magento
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@magentocommerce.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade Magento to newer
 * versions in the future. If you wish to customize Magento for your
 * needs please refer to http://www.magentocommerce.com for more information.
 *
 * PHP version 5
 *
 * @category  Tinycarts
 * @package   Tinycarts_Catalog
 * @author    Yevgeniy A. Viktorov <wik@rentasite.com.ua>
 * @copyright 2007-2010 CHP Viktorov A.A., Berdyansk, Ukraine
 * @license   http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 * @version   SVN: $Id$
 * @link      http://tinycarts.github.com/
 */

/**
 * The wrapper for Mage_Catalog_Helper_Image.
 *
 * Allows to manage product image extra settings through backend.
 *
 * @category Tinycarts
 * @package  Tinycarts_Catalog
 * @author   Yevgeniy A. Viktorov <wik@rentasite.com.ua>
 * @license  http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 * @link     http://tinycarts.github.com/
 */
class Tinycarts_Catalog_Helper_Image extends Mage_Catalog_Helper_Image
{
    /**
     * init catalog/image helper
     *
     *  - set image quality
     *
     * @param Mage_Catalog_Model_Product $product       Product Model Object
     * @param mixed                      $attributeName Destination Subdir
     * @param mixed                      $imageFile     Image File
     *
     * @return void
     */
    public function init(
        Mage_Catalog_Model_Product $product, $attributeName, $imageFile=null
    ) {
        $quality = Mage::getStoreConfig("design/product_image_settings/quality");

        return parent::init($product, $attributeName, $imageFile)->setQuality(
            (is_numeric($quality))? $quality : 90
        );
    }
}
